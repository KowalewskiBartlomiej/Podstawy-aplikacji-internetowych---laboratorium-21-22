﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SongsApp.Models;

namespace SongsApp.Controllers
{
    public class SongsController1 : Controller
    {
        // GET: Songs
        public ActionResult Index()
        {
            Song s1 = new Song();
            s1.Artist = "Lenka";
            s1.GenreId = 0;
            s1.Id = 1;
            s1.Title = "Show";

            return View(s1);
        }

        public ActionResult Square(int id)
        {
            return Content((id * id).ToString());
        }
    }
}